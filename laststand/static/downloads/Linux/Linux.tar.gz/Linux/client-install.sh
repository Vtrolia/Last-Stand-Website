#!/bin/bash
#
# This script will install the client, ensuring all the dependencies are installed then
# moving all needed files to their needed directories. Much simpler than the server
# version, does require you to login to your Last Stand Cloud Software account so that it
# doesn't have to be entered every single time the client is run. That is annoying

# must be run as root
if [ $(whoami) != "root" ];
then
    printf "ERROR: please rerun script as root: sudo ./install.sh\n"
    exit 1
fi

printf "Welcome to Last Stand Cloud!\n\n"
sleep 1
clear

# to install the dependencies, find the user's package manager
dependencies=("openssl" "curl" "pgrep" "python3" "sqlite3" "cron")
apt=$(which apt)
yum=$(which yum)
pacman=$(which pacman)
brew=$(which brew)
pkg=$(which pkg)


# for each different package manager, go through each of the required libraries and install them. Because of how Homebrew works, on macOS the user must
# install them manually.
if [ ! -z $brew ];
then
    printf "Homebrew unable to use sudo privileges, please manually install: \n"
    needed=0
    for dep in ${dependencies[@]}
    do
        temp=$(which $dep)
        if [ -z $temp ];
        then
            needed=needed+1
            echo $dep
        fi
    done
    
    if [ needed ];
    then
        printf "All packages installed!"
    else
        exit 0
    fi
elif [ ! -z $yum ];
then
    for dep in ${dependencies[@]}
    do
        yum install $dep
    done
elif [ ! -z $packman ];
then
    for dep in ${dependencies[@]}
    do
        pacman install $dep
    done
elif [ ! -z $apt ];
then
    for dep in ${dependencies[@]}
    do
        apt install $dep
    done
elif [ ! -z $pkg ];
then
    for dep in ${dependencies[@]}
    do
        pkg install $dep
    done
else
    printf "Could not identify your package manager."
    exit 2
fi
clear

# get the user's login information
printf "Enter your username: "
read username

while [ ${#username} == 0 ]
do
    printf "please try again: "
    read username
done

printf "Enter your password: "
read password


while  [ ${#password} == 0 ]
do
    printf "please try again: "
    read password
done

# Make sure the provided login is valid on the website
curlres=$(curl -sS -d '{"username": "'"${username}"'", "password": "'"${password}"'"}' -H "Content-Type: application/json" -X post https://laststandcloud.com/api/verify/login)
if [ "$curlres" != "VALID" ];
then
    printf "\nInvalid login. Please try again"
    exit 1
fi

# move the needed files
mkdir /usr/local/etc/laststandclient 2> /dev/null
chmod 777 laststandcloud
cp laststandcloud /usr/local/bin
cp server_id /usr/local/etc/laststandclient
chmod 777 run_jobs.sh
cp run_jobs.sh /usr/local/etc/laststandclient


# create background process database and create the table
touch /usr/local/etc/laststandclient/bg.sqlite3
chmod 777 /usr/local/etc/laststandclient/bg.sqlite3
sudo sqlite3 /usr/local/etc/laststandclient/bg.sqlite3 "CREATE TABLE backgrounds(id INTEGER PRIMARY KEY, file TEXT, hours INTEGER, pid INTEGER);"
sudo sqlite3 /usr/local/etc/laststandclient/bg.sqlite3 "CREATE TABLE auth(id INTEGER PRIMARY KEY, username TEXT, password_crypt TEXT);"
sudo sqlite3 /usr/local/etc/laststandclient/bg.sqlite3 "INSERT INTO auth(username, password_crypt) VALUES (\"$username\", \"$password\");"

# set up to run the periodic client backups every time the computer reboots
( sudo crontab -l ; echo "@reboot /usr/local/etc/laststandclient/run_jobs.sh") | sudo crontab -
