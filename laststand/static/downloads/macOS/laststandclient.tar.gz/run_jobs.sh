#!/bin/bash

# Get the user's login info stored in the database
auth=$(sqlite3 /usr/local/etc/laststandclient/bg.sqlite3 "SELECT username, password_crypt FROM auth;")
user_auth=($(echo $auth | tr "|" "\n"))

# get the backups they have selected
jobs=$(sqlite3 /usr/local/etc/laststandclient/bg.sqlite3 "SELECT file, hours FROM backgrounds;")
jobs=$(echo $jobs | tr " " "\n" | tr "|" " ")

REAL_IFS=$IFS
IFS=$'\n'
for job in $jobs
do
    IFS=$REAL_IFS
    job=($job)
    
    # call last stand cloud client to run each backup in the database
    printf "${user_auth[0]}\n${user_auth[1]}\n${job[0]}\n" | laststandcloud -t ${job[1]}
done

