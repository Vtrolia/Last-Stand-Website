#!/bin/bash

# get the backups they have selected
jobs=$(sqlite3 /usr/local/etc/laststandclient/bg.sqlite3 "SELECT file, hours, server FROM backgrounds;")
jobs=$(echo "$jobs" | tr " " "\n" | tr "|" " ")
REAL_IFS=$IFS
IFS=$'\n'
for job in $jobs
do
    IFS=$REAL_IFS
    job=($job)
    
    # call last stand cloud client to run each backup in the database
    printf "%s\n%s" "${job[0]}" "${job[2]}" | laststandcloud -t "${job[1]}"
done

