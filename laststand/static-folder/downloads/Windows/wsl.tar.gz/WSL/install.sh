#!/bin/bash

# This is the installer script for Last Stand Cloud's Server. It will find your Operating System's package manager, install the requirements and set
# The laststand.conf file to have the settings that you select. You can, of course, edit laststand.conf on your own, but for most users and most
# use cases using this script to set up everything will work. Supported Operating Systems: macOS, FreeBSD, Debian-based Linux, Arch-based Linux, RHEL-based Linux.
# Additional operating systems will be added if there is more demand. For now, this script supports the launchd, systemd, and rc.d daemon systems, and will install
# itself as a launch, global daemon for which one of the systems your computer uses. For Linux and FreeBSD systems for maximum compatibility, it is best
# to run this script as
# 'sudo bash ./install.sh'
# from the directory it was downloaded in.

# user must launch this script as root
if [ "$(whoami)" != "root" ];
then
    printf "ERROR: please rerun script as root: sudo ./install.sh\n"
    exit 1
fi

printf "Welcome to Last Stand Cloud!\n\n"
sleep 1
clear

# to install the dependencies, find the user's package manager
dependencies=("openssl" "curl" "pgrep" "python3" "sqlite3")
apt=$(command -v apt)
yum=$(command -v yum)
pacman=$(command -v pacman)
brew=$(command -v brew)
pkg=$(command -v pkg)


# for each different package manager, go through each of the required libraries and install them. Because of how Homebrew works, on macOS the user must
# install them manually.
if [ -n "$brew" ];
then
    printf "Homebrew unable to use sudo privileges, please manually install: \n"
    needed=0
    for dep in "${dependencies[@]}"
    do
        temp=$(command -v "$dep")
        if [ -z "$temp" ];
        then
            needed=$((needed + 1))
            echo "$dep"
        fi
    done
    
    if [ $needed == 0 ];
    then
        printf "All packages installed!"
    else
        exit 0
    fi
elif [ -n "$yum" ];
then
    for dep in "${dependencies[@]}"
    do
        yum install "$dep"
    done
elif [ -n "$pacman" ];
then
    for dep in "${dependencies[@]}"
    do
        pacman install "$dep"
    done
elif [ -n "$apt" ];
then
    for dep in "${dependencies[@]}"
    do
        apt install "$dep"
    done
elif [ -n "$pkg" ];
then
    for dep in "${dependencies[@]}"
    do
        pkg install "$dep"
    done
else
    printf "Could not identify your package manager."
    exit 2
fi

clear
# begin to fill the config file
cp laststand-base.conf laststand.conf

# prompt the user for a valid username and password now, so that it can be authenticated before the server is run
printf "To get started, please log into your account:\n\n"
printf "Enter your username: "
read username

while [ ${#username} == 0 ]
do
    printf "please try again: "
    read username
done

printf "Enter your password: "
read password


while  [ ${#password} == 0 ]
do
    printf "please try again: "
    read password
done

# now the user's login is validated using Last Stand Cloud's API verification service
curlres=$(curl -c cookies -sS -d '{"username": "'"${username}"'", "password": "'"${password}"'"}' -H "Content-Type: application/json" -X post https://laststandcloud.com/api/verify/login)

if [ "$curlres" == "VALID" ];
then
    # if the login is legitimate and belongs to an account, keep them logged in and the grab the names and IDs of the clouds that they own
    cloud=$(curl -b cookies -sS https://laststandcloud.com/api/get-user-clouds)
    echo "#This is your user login information used when the server periodically updates itself on the website." >> laststand.conf
    echo "#This information must match the owner of the cloud. " >> laststand.conf
    
    # pass the authenticated login info to laststand.conf
    echo "USERNAME = $username" >> laststand.conf
    printf "PASSWORD = %s\n" "$password" >> laststand.conf
    
    # the information given back by Last Stand Cloud's API is in the form of a JSON object. In order to parse it and get more information from the user,
    # that information is passed to a python installer script
    python3 install.py "$cloud"
    rm cookies
    
    # The user has the option to use the built-in support from Last Stand Verify if they so choose. Last Stand Verify will periodically issue a new certificate
    # to any cloud who asks if their certificate is no longer valid. Otherwise, everything is up to the user themselves.
    ver="false"
    while [ "$ver" =  "false" ]
    do
        printf "Do you want to use Last Stand Verify for security? (info for more information): \n"
        select verify in yes no info
        do
            case $verify in
            "info")
            printf "Last Stand Cloud does not allow for self signed ssl certificates, you can choose to try setting up your own service with a Certificate Authority, but using Last Stand Verify will be done for you automatically\n"
            break
            ;;
            "yes" | "no")
                # warn the user that they must set CACERT_PATH in laststand.conf if they elect not to use Last Stand Verify
                if [ "$verify" = "no" ];
                then
                    printf "Make sure you remember to add your certificate's path to CACERT_PATH and uncomment it\n"
                fi
                
                # print the information to laststand.cong
                echo "#Whether or not to use Last Stand Verify's service. If not, set CACERT_PATH to the certificate's path" >> laststand.conf
                echo "USE_VERIFY = $verify" >> laststand.conf
                printf "#CACERT_PATH = \n" >> laststand.conf
                ver="true"
                break
                ;;
            *)
            printf "Invalid option\n"
            break
            ;;
        esac
        done
    done
    
else
    printf "Invalid login, please try again\n"
    exit 3
fi


# generate a new private key if one does not already exist, to not break everyone's servers when installing an update
if [[ ! -e /usr/local/etc/laststandcloud/privkey.pem ]];
then
    openssl genrsa -out privkey.pem 2> /dev/null
    cp privkey.pem /usr/local/etc/laststandcloud/privkey.pem
fi

printf "Initialize the cloud now? (no if not running Last Stand Verify)?\n"
select choice in yes no
do
    case $choice in yes)
        # if the user is using macOS, install the configuration and set the executable to work with launchd
        if [[ "$OSTYPE" == "darwin"* ]];
        then
            cp distributions/macOS/cnf/com.laststandcloud.serverdaemon.plist /Library/LaunchDaemons/com.laststandcloud.serverdaemon.plist
            launchctl load -w /Library/LaunchDaemons/com.laststandcloud.serverdaemon.plist
            chmod 600 /Library/LaunchDaemons/com.laststandcloud.serverdaemon.plist
            launchctl start /Library/LaunchDaemons/com.laststandcloud.serverdaemon.plist

        # if FreeBSD is the distribution the user has, set up for rc.d
        elif [[ "$OSTYPE" == "FreeBSD" ]];
        then
            cp distributions/FreeBSD/cnf/laststandserverd /usr/local/etc/rc.d/laststandserverd
            chmod +x /usr/local/etc/rc.d/laststandserverd
            echo laststandserverd_enable="YES" >> /etc/rc.conf
            service laststandserverd enable
            
        # the only other daemon supported is systemd, despite its reputation
        else
            cp distributions/Linux/cnf/laststandserverd.service /etc/systemd/system/laststandserverd.service
            systemctl enable laststandserverd
            systemctl start laststandserverd
        fi
        break
        ;;
    *)
        printf "Cloud not enabled, please manually load it into your init system manually\n"
        break
        ;;
    esac
done

# create the directories needed and move all the files used by Last Stand Cloud Server to the /usr/local/etc/laststandcloud directory
mkdir /usr/local/etc/laststandcloud 2> /dev/null
mkdir /usr/local/etc/laststandcloud/conf 2> /dev/null
mkdir /usr/local/etc/laststandcloud/backupfiles 2> /dev/null
cp laststandserver /usr/local/bin/laststandserverd
chmod 777 /usr/local/bin/laststandserverd
cp csr_gen.sh /usr/local/etc/laststandcloud/csr_gen.sh
cp laststand.conf /usr/local/etc/laststandcloud/conf/laststand.conf

# create and formulate the file hash database
touch /usr/local/etc/laststandcloud/file_hashes.sqlite3
chmod 777 /usr/local/etc/laststandcloud/file_hashes.sqlite3
sqlite3 /usr/local/etc/laststandcloud/file_hashes.sqlite3 "CREATE TABLE files(id INTEGER PRIMARY KEY, filename TEXT, sha1 TEXT);"

exit 0
