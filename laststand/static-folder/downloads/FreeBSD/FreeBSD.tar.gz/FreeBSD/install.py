import json as j
import sys

# install.sh will passa json object representing the user's clouds, parse it
jscript = sys.argv[1]
va = j.loads(jscript)
names = ""

# prompt the user for the cloud they want this to be
print("\nWhich cloud do you want this to be?")
count = 1
for v in va.keys():
    print(str(count) + ". " + v)
    count += 1
choice = 0
while True:
    try:
        choice = int(input("Select a number: "))
        if (choice >= count or choice < 1):
            continue
        else:
            break
    except:
        continue
        
# store the result in laststand.conf
i = 0
the_key = ""
for v in va.keys():
    if i + 1 == choice:
        the_key = v
        break
    else:
        i += 1
with open("laststand.conf", "a") as f:
    f.write("#THIS IS THE ID NUMBER LAST STAND CLOUD'S API USES TO IDENTIFY YOUR SERVER, DO NOT EDIT OR DELETE IT\n")
    f.write("#YOUR SERVER WILL NOT WORK IF IT IS CHANGED\n")
    f.write("SERVER_ID = " + va[the_key] + "\n\n")
