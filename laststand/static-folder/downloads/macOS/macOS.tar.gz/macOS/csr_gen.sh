#!/bin/bash

commoname=$1
country=US
state=Illinois
locality=Chicago
organization="Last Stand Cloud"
organizationUnit="Last Stand User Server"
email=laststandcloud@protonmail.com

openssl req -new -key /usr/local/etc/laststandcloud/privkey.pem -out /usr/local/etc/laststandcloud/laststanduser.csr \
	-subj "/C=$country/ST=$state/L=$locality/O=$organization/OU=$organizationUnit/CN=$commoname/emailAddress=$email"
 
 exit 0
